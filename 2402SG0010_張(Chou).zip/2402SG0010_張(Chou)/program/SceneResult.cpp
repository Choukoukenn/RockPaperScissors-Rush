#include "SceneResult.h"
#include "../program/Main.h"
#include "DxLib.h"
#include "../program/Game.h"
#include <cstdio>
#include <cstring>

//---------------------------------------------------------------------------------
// �R���X�g���N�^
//---------------------------------------------------------------------------------
SceneResult::SceneResult(GameState state, int finalScore)
	: m_myState(state), m_finalScore(finalScore)
{
}

//---------------------------------------------------------------------------------
// ����������
//---------------------------------------------------------------------------------
void SceneResult::Init() {}

//---------------------------------------------------------------------------------
// �I������
//---------------------------------------------------------------------------------
void SceneResult::Exit() {}

//---------------------------------------------------------------------------------
// �X�V����
//---------------------------------------------------------------------------------
GameState SceneResult::Update()
{
	// ENTER�L�[�Ń^�C�g���ɖ߂�
	if (PushHitKey(KEY_INPUT_RETURN))
	{
		return GameState::Title;
	}

	// ���݂̏�Ԃ��ێ�
	return m_myState;
}

//---------------------------------------------------------------------------------
// �`�揈��
//---------------------------------------------------------------------------------
void SceneResult::Render()
{
	int screenWidth = SCREEN_W;
	int screenHeight = SCREEN_H;
	float centerX = screenWidth / 2.0f;
	float centerY = screenHeight / 2.0f;

	// UI��`��
	RenderResultUI(screenWidth, screenHeight, centerX, centerY);
}

//---------------------------------------------------------------------------------
// ���U���g��ʂ�UI�`��
//---------------------------------------------------------------------------------
void SceneResult::RenderResultUI(int screenWidth, int screenHeight, float centerX, float centerY)
{
	// �w�i�i���j
	DrawBox(0, 0, screenWidth, screenHeight, GetColor(0, 0, 0), TRUE);

	// �Q�[���N���A���̕\��
	if (m_myState == GameState::Clear)
	{
		const char* titleText = " GAME CLEAR! ";
		char scoreText[64];
		sprintf_s(scoreText, "SCORE: %d", m_finalScore);
		const char* hintText = "[ ENTER ] �L�[�������ă^�C�g����";

		// �����𒆉��ɕ\��
		DrawString((int)(centerX - (((float)GetDrawStringWidth(titleText, (int)strlen(titleText))) / 2.0f)), (int)(centerY - 40), titleText, GetColor(0, 255, 0));
		DrawString((int)(centerX - (((float)GetDrawStringWidth(scoreText, (int)strlen(scoreText))) / 2.0f)), (int)centerY, scoreText, GetColor(255, 255, 255));
		DrawString((int)(centerX - (((float)GetDrawStringWidth(hintText, (int)strlen(hintText))) / 2.0f)), (int)(centerY + 50), hintText, GetColor(200, 200, 200));
	}
	// �Q�[���I�[�o�[���̕\��
	else if (m_myState == GameState::GameOver)
	{
		const char* titleText = " GAME OVER! ";

		char scoreText[64];
		sprintf_s(scoreText, "SCORE: %d", m_finalScore);

		const char* hintText = "[ ENTER ] �L�[�������ă^�C�g����";

		// �����𒆉��ɕ\��
		DrawString((int)(centerX - (((float)GetDrawStringWidth(scoreText, (int)strlen(scoreText))) / 2.0f)), (int)centerY, scoreText, GetColor(255, 255, 255));
		DrawString((int)(centerX - (((float)GetDrawStringWidth(hintText, (int)strlen(hintText))) / 2.0f)), (int)(centerY + 30), hintText, GetColor(200, 200, 200));
	}
}